#include "xchar.h"
#ifdef _WIN32
#pragma message ("fmt/locale.h is deprecated, include fmt/format.h or fmt/xchar.h instead")
#else
#warning fmt/locale.h is deprecated, include fmt/format.h or fmt/xchar.h instead
#endif
